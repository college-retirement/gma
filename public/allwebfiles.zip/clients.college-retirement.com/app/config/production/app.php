<?php

return array(
	
	//Don't show exception messages in production
	'debug' => true,

	// Set production security key (used in encryption and authentication processes)
	'key' => 'EwXnBN7LYptXYUr5qRKT9P0IGJrRFQ7T'
);
