<?php

return [
    'connections' => [
        'mongodb' => array(
            'driver' => 'mongodb',
            'host' => 'localhost',
            'port' => 27017,
            'username' => '',
            'password' => '',
            'database' => 'gma-stage'
        )
    ]
];
