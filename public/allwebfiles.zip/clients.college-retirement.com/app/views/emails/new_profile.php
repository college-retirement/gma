A new profile has been created!
<br><br>
Name: <?=$profile->name['first']?> <?=$profile->name['last']?><br>
<br>
<a href="https://clients.college-retirement.com/#/admin/profiles/<?=$profile->_id?>">View Profile</a>
<br><br>
-------------------------- <br>
This is an automated notification message <br>
--------------------------