A new user account has been created!
<br><br>
Name: <?=$user->full_name?><br>
Email: <?=$user->email?><br>
Role: <?=$user->role?>
<br><br>
-------------------------- <br>
This is an automated notification message <br>
--------------------------