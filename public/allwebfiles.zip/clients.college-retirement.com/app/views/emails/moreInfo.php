Hello <?=$profile['user']['name']?>,
<br><br>
You recently submitted a profile to College & Retirement Solutions.  In order to service your account, we're going to need some more information from you.
<br><br>
Please follow the link below to provide those details.
<br><br>
<a href="https://clients.college-retirement.com/#/moreinfo/<?=$profile['_id']?>">Click here to view the form.</a>
<br><br>
Thank you for your cooperation!
<br>
<br>
Very truly yours, <br>
College & Retirement Solutions <br>
<br>
Phone: (973) 514-2002 <br>
Fax: (973) 514-1101 <br>
<a href="http://college-retirement.com">http://college-retirement.com</a><br><br>
<img src="<?=$message->embed(public_path() . '/assets/img/crs-logo-smaller.png')?>">
<br>
<br>
-------------------------- <br>
This is an automated notification message. <br><br>	
If investment, financial, mortgage or insurance planning or products are required, College and Retirement Solutions, LLC (CRS) may refer you to other firms. Any discussion of the tax implications of planning is strictly for general purposes. Neither CRS nor its representatives may give specific tax advice. Advice and counsel should be sought out from their accountant and/or tax advisor for information regarding their own particular situation. <br>
--------------------------