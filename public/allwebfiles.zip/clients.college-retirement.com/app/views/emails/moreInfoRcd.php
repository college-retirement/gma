More information has been received for <?=$profile->name['first']?> <?=$profile->name['last']?>.
<br><br>
<a href="https://clients.college-retirement.com/#/admin/profiles/<?=$profile->_id?>">View Client Profile</a>
<br><br>
-------------------------- <br>
This is an automated notification message <br>
--------------------------