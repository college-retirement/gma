<?php

use Jenssegers\Mongodb\Model as Eloquent;

class College extends Eloquent {

    protected $collection = 'colleges';

}