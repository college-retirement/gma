angular.module('gmaApp').controller('AdminCtrl', function($scope, Persona){
	
});